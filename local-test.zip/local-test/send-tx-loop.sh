#!/bin/sh
# Continuously send ETH transfer transactions every 0.5s using cast
#
# Default sender: Hardhat/Foundry account #0
#   Address: 0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266
#   Private Key: 0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80
#
# Usage:
#   ./send-tx-loop.sh
#   RPC_URL=http://localhost:8545 TO=0x... VALUE=0.001ether ./send-tx-loop.sh

PRIVATE_KEY="${PRIVATE_KEY:-0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80}"
RPC_URL="${RPC_URL:-http://localhost:8545}"
TO="${TO:-0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266}"
VALUE="${VALUE:-0.001ether}"
INTERVAL="${INTERVAL:-0.5}"

echo "Sending transfers every ${INTERVAL}s"
echo "  From:  $(cast wallet address --private-key "$PRIVATE_KEY" 2>/dev/null)"
echo "  To:    $TO"
echo "  Value: $VALUE"
echo "  RPC:   $RPC_URL"
echo "Press Ctrl+C to stop."
echo ""

COUNT=0
while true; do
  TX=$(cast send \
    --private-key "$PRIVATE_KEY" \
    --rpc-url "$RPC_URL" \
    --value "$VALUE" \
    "$TO" \
    2>&1)
  COUNT=$((COUNT + 1))
  HASH=$(echo "$TX" | grep  "^0x"| head -1)
  if [ -n "$HASH" ]; then
    echo "[#$COUNT] tx: $HASH"
  else
    echo "[#$COUNT] $(echo "$TX" | head -16)"
  fi
  sleep "$INTERVAL"
done
